#ifndef __revision_generated_h__
#define __revision_generated_h__

#define VBOX_SVN_REV 104061

#endif
